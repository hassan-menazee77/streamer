<!-- Lovable branding removed -->
